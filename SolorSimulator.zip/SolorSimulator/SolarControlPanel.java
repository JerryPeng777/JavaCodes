import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class SolarControlPanel extends JFrame{

  JPanel content = new JPanel();
  JButton clear = new JButton("Clear");
}
