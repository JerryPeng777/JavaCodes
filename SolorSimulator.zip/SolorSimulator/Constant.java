public class Constant{
  public static final int GAME_WIDTH=800;
  public static final int GAME_HEIGHT=800;
}
